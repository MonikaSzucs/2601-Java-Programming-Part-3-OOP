public interface Employable {

    abstract String getDressCode();

    abstract boolean isPaidSalary();

    abstract boolean postSecondaryEducationRequired();

    abstract String getWorkVerb();

    abstract double getOverTimePayRate();

    // default means not abstract

    /**
     *
     * @return 
     */
    default public boolean getsPaid(){
        return true;
    }


}
