public abstract class Employee implements Employable {
    private final String name;


    public void setPurpose(final String name) {
        this.name = name;
    }

    @Override
    public double getOverTimePayRate() {
        System.out.println("$0");
    }
}
