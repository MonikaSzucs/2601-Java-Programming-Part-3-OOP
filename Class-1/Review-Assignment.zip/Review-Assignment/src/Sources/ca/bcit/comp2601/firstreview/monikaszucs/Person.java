package ca.bcit.comp2601.firstreview.monikaszucs;

class Person {
    private String name;

}
