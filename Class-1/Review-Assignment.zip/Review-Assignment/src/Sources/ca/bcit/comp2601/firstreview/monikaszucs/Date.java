package ca.bcit.comp2601.firstreview.monikaszucs;

class Date {
    private int     year;
    private String  month;
    private int     day;

    Date(final int year, final String month, final int day) {
        this.year   = year;
        this.month  = month;
        this.day    = day;
    }

}
