package ca.bcit.comp2601.firstreview.monikaszucs;

public class BankAccount extends Person{
}
