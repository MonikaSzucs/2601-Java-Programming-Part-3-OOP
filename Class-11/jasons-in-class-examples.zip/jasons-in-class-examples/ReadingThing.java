import java.io.*;

/*
three threads will read three text files "at the same time"
 */
public class ReadingThing
{
    public void readFromFile(final String f, Thread thread, int id)
    {
        Runnable readRun = new Runnable()
        {
            @Override
            public void run()
            {
                FileInputStream in   = null;
                String          text = null;
                try
                {
                    System.out.println("delay for 4 and a half seconds...");
                    Thread.sleep(4500);
                    System.out.println("4.5 sec delay ending...");

                    File inputFile = new File(f);
                    in = new FileInputStream(inputFile);
                    byte bt[] = new byte[(int)inputFile.length()];
                    in.read(bt);
                    text = new String(bt);
                    System.out.printf("Thread %d finishing...\n", id);

                    // with multithreading, we cannot predict the exact order of output
                    // because it varies from JVM to JVM and system to system

                    // comment the next line out and run several times to see things start in the
                    // same order (1,2,3) but finish in a variety of orders
                    //System.out.println(text);
                }
                catch(Exception e)
                {
                    e.printStackTrace();
                }
            }
        };

        // now we must either (a) implement Runnable interface or
        // (b) extend Thread and override run()
        // Note that (a) allows us to still extend another class (so is often preferable)
        thread = new Thread(readRun);

        System.out.println("Thread " + id + " starting...");
        thread.start(); // execute the run() method right away
    }

    public static void main(final String[] args)
    {
        ReadingThing thing = new ReadingThing();

        Thread thread1 = null;
        Thread thread2 = null;
        Thread thread3 = null;

        String f1 = "a.txt";
        String f2 = "b.txt";
        String f3 = "c.txt";

        thing.readFromFile(f1, thread1, 1); // id is useless...just for a print statement i'm using
        thing.readFromFile(f2, thread2, 2);
        thing.readFromFile(f3, thread3, 3);

    }
}
