import java.util.LinkedList;
import java.util.List;
import java.util.concurrent.*;

public class CalculatorFutureTask
{
    public static void main(final String[] args)
    {
        final ExecutorService executor;
        final Future<Integer> future;

        final List<Integer> primesTo200000 = new LinkedList<>();

        // make a thread to run this looooong task without blocking the whole program
        executor = Executors.newFixedThreadPool(2);

        System.out.println("this is a line of code before starting the future task of getting sum of primes");
        System.out.println("without use of the future task next, we would not see any prints for a few seconds");

        // tell the executor to do this function (which must be Callable), and which returns an Integer in this case
        // when the thread starts, it will automatically invoke the call() method and the future gets the return value
        // (we can call get() on the future to get its value)
        future = executor.submit(new Prime(primesTo200000)); // pass in empty list to get filled up

        System.out.println("WITH the future, this line of code runs right away after starting the future task");
        System.out.println("this main thread of the program continues to run instead of blocking/waiting");

        try
        {
            final int result;

            future.cancel(true); // gives a CancellationException
            result = future.get(10, TimeUnit.SECONDS); // get a timeoutexception if not done in 10 seconds
            System.out.println("the result is " + result);
        }
        catch(final TimeoutException e)
        {
            future.cancel(true); // not done in the allotted 10 seconds
            e.printStackTrace();
        }
        catch(final InterruptedException | ExecutionException e)
        {
            e.printStackTrace();
        }
        catch(final CancellationException e)
        {
            System.out.println("canceled!!!!!!!!!");

        }
        finally
        {
            // do this, or else if the future is canceled etc, the program won't exit
            // this is a perfect example for "finally" code
            executor.shutdown();
        }
    }

    private static class Prime implements Callable<Integer> // return an Integer: the sum
    {
        private static List<Integer> primes;

        Prime(final List<Integer> p) // pass in empty list; this class will fill it up with primes
        {
            primes = p;
        }

        @Override
        public Integer call() throws InterruptedException
        {
            final int sum;

            System.out.println("Starting calculation");
            sum = getPrimesUpTo(200000).stream().reduce(0, Integer::sum);
            System.out.println("Finished calculation");
            return sum;
        }

        public static List<Integer> getPrimesUpTo(int n)
        {
            List<Integer> primeNumbers = new LinkedList<>();
            for(int i = 2; i <= n; i++)
            {
                if(isPrime(i))
                {
                    primeNumbers.add(i);
                }
            }
            return primeNumbers;
        }

        public static boolean isPrime(int number)
        {
            // done the slow way on purpose to slow things down
            for(int i = 2; i < number; i++)
            {
                if(number % i == 0)
                {
                    return false;
                }
            }
            return true;
        }
    }
}
