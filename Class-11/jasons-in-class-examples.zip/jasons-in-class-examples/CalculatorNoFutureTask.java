import java.util.LinkedList;
import java.util.List;

public class CalculatorNoFutureTask
{
    public static void main(final String[] args)
    {
        System.out.println("starting the calculation");
        System.out.println(getPrimesUpTo(200000).stream().reduce(0, Integer::sum));
        System.out.println("finished the calculation");
    }

    public static List<Integer> getPrimesUpTo(int n)
    {
        List<Integer> primeNumbers = new LinkedList<>();
        for(int i = 2; i <= n; i++)
        {
            if(isPrime(i))
            {
                primeNumbers.add(i);
            }
        }
        return primeNumbers;
    }

    public static boolean isPrime(int number)
    {
        // done the slow way on purpose to slow things down
        for(int i = 2; i < number; i++)
        {
            if(number % i == 0)
            {
                return false;
            }
        }
        return true;
    }
}
