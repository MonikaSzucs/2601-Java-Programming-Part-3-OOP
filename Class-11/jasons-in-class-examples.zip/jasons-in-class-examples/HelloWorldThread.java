public class HelloWorldThread implements Runnable
{
    @Override
    public void run()
    {
        System.out.println("Hi from a THREAD!");
    }

    public static void main(final String[] args)
    {
        (new Thread(new HelloWorldThread())).start();
    }
}