/*
Let's "synchronize" methods (or code blocks) so that only ONE thread
at a time can execute. The two threads will take turns saying "I'll wait" and
"I'll notify you when it's your turn to run". Let's print the numbers from
1 to 100 by carefully controlling access to methods by the two threads:
they will take turns. One will print an odd number, then notify the other
thread that it is that thread's turn, and the first thread will wait. That
other thread will print an even number, then notify the first thread that it is
its turn again, and this thread will wait.

Thread 1:
It's my turn. I'll print an odd number n and increment n. Then it will notify
Thread 2 that it's Thread 2's turn, and Thread 1 will wait.

Thread 2:
When notified, it will run its code to print n and increment n. Then it notify
Thread 1 that it's Thread 1's turn, and Thread 2 will wait.
*/
public class NumberThing
{
    private int n = 1;
    private static int MAX;

    synchronized public void displayEvenNumber()
    {
        // synchronized code blocks (or instance methods or static methods) will be executed by only ONE thread
        // at a time. This provides locking and ensures mutually-exclusive access to this section of code and
        // prevents race conditions.
        while(n <= MAX)
        {
            while(n % 2 == 0)
            {
                try
                {
                    // suspend this thread to wait until another thread calls notify on the same object
                    //
                    wait();
                }
                catch(InterruptedException e)
                {
                    e.printStackTrace();
                }
            }
            System.out.print(n + " ");
            n++;
            // notify the other thread which is waiting for this lock
            notify(); // wake up the other thread
        }
    }

    public void displayOddNumber()
    {
        // "this" is the current owner (the monitor object): only a single thread per monitor object can execute
        // inside this code block (for static methods:
        // public static void displayOddNumber()
        // {
        //     synchronized(NumberThing.class)
        //     {
        //         // methods...
        synchronized(this)
        {
            while(n <= MAX)
            {
                while(n % 2 == 1)
                {
                    try
                    {
                        wait();
                    }
                    catch(InterruptedException e)
                    {
                        e.printStackTrace();
                    }
                }
                System.out.print(n + " ");
                n++;
                notify(); // wake up the other thread
            }
        }
    }

    public static void main(String[] args)
    {
        MAX = 100000;
        NumberThing numberThing = new NumberThing();
        Thread evenThread = new Thread(new Runnable()
        {
            @Override
            public void run()
            {
                // call the displayEvenNumber() method using thread evenThread
                numberThing.displayEvenNumber();
            }
        });

        Thread oddThread = new Thread(new Runnable()
        {
            @Override
            public void run()
            {
                numberThing.displayOddNumber();
            }
        });

        System.out.println("starting even thread");
        evenThread.start();

        // will print right away, before the previous line finishes executing
        System.out.println("starting odd thread");
        oddThread.start();

        System.out.println("the rest of the program keeps running, like this!");
    }
}
