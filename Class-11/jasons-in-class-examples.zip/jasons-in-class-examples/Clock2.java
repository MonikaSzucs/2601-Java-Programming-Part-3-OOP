import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

/*
let's start a timer and increment a clock by one second, every second
and write the time to the screen in hh:mm:ss format

incrementing the time must go:

19:08:58
19:08:59
19:09:00
19:09:01

AND

let's start a second time that prints an unrelated number to the screen every 3.5 seconds
 */
public class Clock2
{
    private static int hour;
    private static int minute;
    private static int second;

    private static int number;

    public static final int SEC_PER_MIN = 60;
    public static final int MIN_PER_HR = 60;
    public static final int HR_PER_DAY = 24;

    public static final int RESET = 0;
    public static final int DOUBLE_DIGITS = 10;
    public static final int LEADING_ZERO = 0;

    //private static final Timer timer;
    private static final ScheduledExecutorService executor;

    private static String timeString;

    static
    {
        //timer = new Timer();
        executor = Executors.newScheduledThreadPool(2);
        number = 555;
    }

    private static void incrementOneSecond()
    {
        second++;

        if(second >= SEC_PER_MIN)
        {
            second = RESET;
            minute++;

            if(minute >= MIN_PER_HR)
            {
                minute = RESET;
                hour++;
                if(hour >= HR_PER_DAY)
                {
                    hour = RESET;
                }
            }
        }
        printTime();
    }

    private static void printTime()
    {
        timeString = "";
        timeString += (hour < DOUBLE_DIGITS) ? LEADING_ZERO : "";
        timeString += hour;
        timeString += ":";

        timeString += (minute < DOUBLE_DIGITS) ? LEADING_ZERO : "";
        timeString += minute;
        timeString += ":";

        timeString += (second < DOUBLE_DIGITS) ? LEADING_ZERO : "";
        timeString += second;


        System.out.println(timeString);
    }

    public static void main(final String[] args)
    {
        //timer.scheduleAtFixedRate(new RunnableTimerTask(Clock::incrementOneSecond), 3000, 1000);
        executor.scheduleAtFixedRate(Clock2::incrementOneSecond, 0, 1, TimeUnit.SECONDS);

        System.out.println("notice how the rest of this program keeps running....");
        System.out.println("even while the timer goes on and on and on");

        System.out.println("A SECOND TIMER WILL NOW PRINT SOME NUMBERS OUT EVERY 2.6 SECONDS");
        // timer.scheduleAtFixedRate(new RunnableTimerTask(Clock::printNumber), 1500, 2600);
        executor.scheduleAtFixedRate(Clock2::printNumber, 1500, 2600, TimeUnit.MILLISECONDS);

        //timer.schedule(new RunnableTimerTask(Clock::killTimer), 66000);
        executor.schedule(Clock2::killTimer, 66, TimeUnit.SECONDS);

    }

    private static void killTimer()
    {
        System.out.println("the end");
        //timer.cancel();
        executor.shutdown();
    }

    private static void printNumber()
    {
        System.out.println(number);
        number++;
    }


}
